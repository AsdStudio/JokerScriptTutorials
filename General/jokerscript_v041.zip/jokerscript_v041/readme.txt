﻿JOKER SCRIPT ｜ジョーカースクリプト　Ver0.4.1（C）STRIKEWORKS / ShikemokuMK

http://jokerscript.jp


■使い方■

公式ページにチュートリアルとタグリファレンスがありますので参考にしてください

【タグリファレンス】
http://jokerscript.jp/home/tag

【使い方＆チュートリアル】
http://jokerscript.jp/usage/tutorial/about


■利用規約■

ジョーカースクリプトは
個人利用において、商用・非商用問わず、無料で利用することが可能です。
法人での利用にも制限はありません。

著作権はシケモクMKが所持します。
ジョーカースクリプト自体を改変しての再配布は禁止します。
ただし、ゲームとして利用する用途に限り改変を認めます。
　
■免責事項■

本ツールを利用したことによって損害・不利益・事故等が
発生した場合でも、一切の責任を負いません。


■連絡先■

メール
shikemokumk@gmail.com

Twitter
http://twitter.com/shikemokumk


■謝辞■
以下の素材を利用させて頂きました。

ぴたちー素材館　様
http://www.vita-chi.net/sozai1.htm

DOVA SYNDROME 様
http://dova-s.jp/

SUGAR STAR 様
http://sgst.x.fc2.com/sozai/sozai_base.htm

ティラノユーザー会

■主な更新履歴■

V0.4.1 (2015/12/20)
Unity5.2対応
文字周りのバグ修正

V0.4.0 (2015/10/30)
Unity5.2対応

V0.3.0 (2015/5/6)
Unity5.0対応

V0.2.0 (2015/2/20)
uGUI対応
Live2D正式サポート
動作高速化

V0.0.3 (2014/12/20)
Unity4.6に対応
縦画面のゲームに対応
細かいバグ修正

V0.0.2 (2014/12/4)
安定化対応。

V0.0.1 (2014/10/17)
実験版リリース！

---------------------------------------------------------------------

